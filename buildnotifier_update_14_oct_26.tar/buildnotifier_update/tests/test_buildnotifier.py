import configparser
import hashlib
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from Build_Engine.Distro import parser, builds_announced, builds_copied, new_builds
from Build_Engine.redhat_build_engine import RHEL
from Build_Engine.suse_build_engine import SUSE
from Build_Engine import publishBuild

class CompatibilityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        parser.clear()
        parser.read_dict({'Location': {'base_link': 'ftp://example/suse/',
                                      'dir_structure': str(self.root / 'repo') + '/',
                                      'build_log': str(self.root / 'logs') + '/'}})
        self.rhel = object.__new__(RHEL)
        self.suse = object.__new__(SUSE)
        for obj in (self.rhel, self.suse):
            obj._workspace_root = str(self.root)
            obj.LOG = lambda *args: None
        builds_announced.clear(); builds_copied.clear(); new_builds.clear()
    def tearDown(self):
        self.temp.cleanup()
    def test_rhel_four_releases(self):
        for version in ('9.9', '10.3'):
            self.rhel._read_listing = lambda *args, v=version: ['RHEL-' + v, 'RHEL-' + v + '-NIGHTLY-2026-09-28']
            self.assertEqual(self.rhel.populate_builds_announced('u','p','LE-'+version,'ftp://example/'), 0)
            self.assertEqual(builds_announced, ['NIGHTLY-2026-09-28'])
        for version, iso_version, compose in [('9.10','9.10.0','20260928.0'),('10.4','10.4','20260923.1')]:
            iso='RHEL-'+iso_version+'-'+compose+'-ppc64le-dvd1.iso'
            self.rhel._read_listing=lambda u,p,url,v=version,n=iso: [n] if '/iso/' in url else ['RHEL-'+v]
            self.assertEqual(self.rhel.populate_builds_announced('u','p','LE-'+version,'ftp://example/'),0)
            self.assertEqual(self.rhel._expected_isos[('LE-'+version,builds_announced[0])],iso)
            self.assertIn('RHEL-'+version+'/BaseOS/ppc64le/iso/',self.rhel._source_iso_dir('LE-'+version,builds_announced[0]))
    def test_sles_discovery(self):
        for release, names, expected in [
          ('16.1',['SLE-16.1-RC3-Full','SLE-16.1-GMC-Full','SLE-16.1-GM-Full','SLE-16.1-Snapshot-013','SLE-16.1-RC3-Minimal','SLE-16.0-GM-Full'],['gm','gmc','rc3','snapshot-013']),
          ('15-SP7',['SLE-15-SP7-Full-GM','SLE-15-SP7-Installer-RC2'],['sp7-gm','sp7-rc2'])]:
            self.suse._read_listing=lambda *args,n=names:n
            self.assertEqual(self.suse.populate_builds_announced('u','p',release,'ftp://example/'),0)
            self.assertEqual(builds_announced,expected)
        self.assertEqual(self.suse.release_directory('16.1'),'16sp1')
        self.assertEqual(self.suse.release_directory('15-SP7'),'15sp7')
    def test_checksums_and_corruption(self):
        iso='SLES-16.1-Full-ppc64le-GM.install.iso'
        for algo in ('md5','sha256','sha512'):
            digest=hashlib.new(algo,b'good').hexdigest()
            for text in [digest+'  '+iso,digest+'  4 '+iso,algo.upper()+' ('+iso+') = '+digest]:
                self.assertEqual(self.suse._parse_checksums(text)[iso],(algo,digest))
            file=self.root/iso;file.write_bytes(b'good')
            self.assertTrue(self.suse._verify_file(str(file),algo,digest))
            file.write_bytes(b'bad')
            self.assertFalse(self.suse._verify_file(str(file),algo,digest))
    def test_sles_flat_and_arch_download(self):
        iso='SLES-16.1-Full-ppc64le-014-RC3.install.iso'
        digest=hashlib.sha512(b'good').hexdigest()
        for archdir in (True,False):
            dest=self.root/str(archdir);dest.mkdir()
            self.suse._suse_sources={'rc3':'SLE-16.1-RC3-Full'}
            self.suse._read_listing=lambda u,p,url: ['ppc64le'] if archdir and not url.endswith('/ppc64le/') else [iso,iso+'.sha512']
            self.suse._download_text=lambda *a:digest+'  '+iso+'\n'
            calls=[]
            def fake(args):
                calls.append(args);Path(args[-1]).write_bytes(b'good');return 0
            with patch('subprocess.call',fake):
                self.assertEqual(self.suse.copy_suse_build('u','p','16.1','rc3',str(dest)),0)
            self.assertEqual((dest/iso).read_bytes(),b'good')
            self.assertEqual('/ppc64le/' in calls[0][-4],archdir)
            with patch('subprocess.call',side_effect=AssertionError('should reuse valid ISO')):
                self.assertEqual(self.suse.copy_suse_build('u','p','16.1','rc3',str(dest)),0)
    def test_collective_and_failed_download(self):
        iso='SLES-16.1-Full-ppc64le-GM.install.iso';digest=hashlib.sha256(b'good').hexdigest()
        self.suse._suse_sources={'gm':'SLE-16.1-GM-Full'}
        self.suse._read_listing=lambda *a:[iso,'SHA256SUMS']
        self.suse._download_text=lambda *a:digest+'  '+iso
        with patch('subprocess.call',return_value=4):
            self.assertEqual(self.suse.copy_suse_build('u','p','16.1','gm',str(self.root)),1)
        self.assertFalse((self.root/iso).exists())
    def test_publish_failure_not_tracked(self):
        new_builds.append('gm')
        self.suse.copy_suse_build=lambda *a:0
        self.suse.publish_build=lambda *a:1
        self.suse.notify_jenkins=lambda *a:self.fail('must not notify')
        self.suse.update_builds_copied=lambda *a:self.fail('must not track')
        self.assertEqual(self.suse.initiate_suse_build_copy('u','p','16.1',str(self.root)),1)
    def test_publish_flatten_then_notify(self):
        new_builds.append('rc3');events=[]
        self.suse.copy_suse_build=lambda *a:0
        def publish(*args):
            destination=Path(args[3][0]);boot=destination/'install/boot/ppc64le/loader';boot.mkdir(parents=True)
            (boot/'linux').write_text('kernel');(boot/'initrd').write_text('initrd');return 0
        self.suse.publish_build=publish
        def fake_cp(args):
            import shutil
            shutil.copytree(args[2].removesuffix('/.'),args[3],dirs_exist_ok=True);return 0
        self.suse.notify_jenkins=lambda *a:events.append('notify')
        self.suse.update_builds_copied=lambda *a:events.append('track')
        with patch('subprocess.call',fake_cp):
            self.assertEqual(self.suse.initiate_suse_build_copy('u','p','16.1',str(self.root)),0)
        self.assertEqual(events,['notify','track'])
        self.assertTrue((self.root/'repo/16sp1/rc3/boot/ppc64le/linux').exists())
    def test_petitboot_paths(self):
        publishBuild.variables_publish={'repo_server':'http://ci-http-results','build_path':'unused'}
        for release,location,kernel in [('10.4le','/home/jenkins/http_repo/crtl/repo/rhel/','images/pxeboot/vmlinuz'),('16sp1','/home/jenkins/http_repo/crtl/repo/sles/','boot/ppc64le/linux')]:
            file=self.root/'petitboot.conf'
            self.assertEqual(publishBuild.create_Petitboot(release,'gm',location,str(file),'No'),0)
            self.assertIn(kernel,file.read_text())
            self.assertIn('/crtl/repo/',file.read_text())
    def test_retry_keeps_directories(self):
        folder=self.root/'build_notifier';folder.mkdir()
        self.rhel.restore_for_copy_again('10.3le','build',str(self.root))
        self.assertTrue(folder.exists())

if __name__=='__main__':unittest.main()
