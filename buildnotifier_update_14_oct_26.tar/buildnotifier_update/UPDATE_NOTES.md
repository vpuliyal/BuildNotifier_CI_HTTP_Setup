# BuildNotifier update: RHEL and SLES

This is an overlay for **buildnotifier_oct_2026.tar**, compared against the LTC
**buildnotifier-main.zip**. Extract it over your existing workspace. It contains
updated code, these notes and offline tests. Your existing configuration,
credentials, logs and copied-build tracking files are retained on the server.

## Comparison and changes

| Area | October package | LTC package | Updated overlay |
|---|---|---|---|
| Dispatcher | Calls RHEL; SLES commented out | Updated SLES implementation | Both enabled, or select `--platform` |
| SLES version matching | Older `15-SPx` parsing | Adds `16.1` matching | Supports `15-SPx` and `16.x` |
| SLES ISO layout | Assumes Media1/Media2 checksums | Adds flat and `ppc64le/` layouts | Discovers exact ISO and checksum names |
| SLES checksums | Inherited mismatch checker returns success | Includes SHA files but retains inherited verification | Checks MD5/SHA256/SHA512; rejects missing hashes or corruption |
| SLES install tree | Does not flatten the new layout | Flattens `install/` | Copies full contents including existing directory merges; exposes kernel/initrd |
| RHEL | Contains the recent dated/rolling fixes | Older RHEL code | Retains October fixes for 9.9, 9.10, 10.3, 10.4 |
| Publishing | Legacy PowerKVM paths; absolute log path duplicated; no return status | Similar integration assumptions | Modern RHEL/SLES boot paths; failures prevent tracking/notification |
| Retry | Shared cleanup tries `os.remove()` on directories | Existing-file skip without verification | Preserves directories; downloads `.part` files; reuses only verified ISOs |
| Shared state | Reuses parser/global lists between distros | Similar shared state | Clears config between distros and lists between releases |

The SLES discovery/checksum layout logic is ported from LTC and integrated with
fixes. This overlay polls installation builds (Full/Installer/Server), not
separate SDK/Packages repositories. Source/debug companion ISOs are downloaded
when advertised alongside an installation ISO and have usable checksums.
Minimal, Online and VMware variants are excluded.

SLES destination names use lower case, consistent with LTC Jenkins identifiers:
`16sp1/rc3`, `16sp1/gmc`, `16sp1/gm`, `16sp1/snapshot-013`.
The manual copy_iso.sh used upper-case RC3/GMC folders; those existing folders
are not migrated or removed. Configure installation jobs to use the newly
published lower-case build path.

## Apply

Stop any currently running BuildNotifier job before replacing its scripts.
Place this tarball on ci-http-results, then run:

```bash
cd /home/jenkins/workspace/buildnotifier
tar -czf ../buildnotifier_before_update.tar.gz Build_Engine start_build_notification.py config
tar -xzf /path/to/buildnotifier_rhel_sles_update.tar.gz --strip-components=1 -C /home/jenkins/workspace/buildnotifier
/usr/bin/python3.9 -m compileall -q Build_Engine start_build_notification.py
/usr/bin/python3.9 tests/test_buildnotifier.py
```

No configuration is included in the archive, so the extraction retains yours.
Update the following settings manually.

### SLES: config/suse_config.ini

```ini
[Location]
releases=16.1
base_link=ftp://ftp3install.linux.ibm.com/suse/beta_cds/sle/
dir_structure=/home/jenkins/http_repo/crtl/repo/sles/
```

For SLES 15 SP7 and 16 SP1 together use `releases=15-SP7,16.1`.
Retain all your other entries, including Email FTP credentials and Jenkins
poll locations. Relative log/tracking paths are now resolved against the
workspace. Both relative and absolute values are supported.

### RHEL: config/rhel_config.ini

```ini
[Location]
releases=LE-9.9,LE-9.10,LE-10.3,LE-10.4
base_link=ftp://ftp3install.linux.ibm.com/redhat/beta_cds/NIGHTLY/RHEL-10/
dir_structure=/home/jenkins/http_repo/crtl/repo/rhel/
```

Select only the releases you want to poll. For a NIGHTLY base ending in
`RHEL-9/` or `RHEL-10/`, the RHEL runner chooses the correct major-version base
for each configured release. Newly appearing dated builds are downloaded when
they are absent from your tracking files. Rolling directories use the ISO
compose identifier, including its revision, as the local build ID.

### Publishing: config/publish_config

The supplied October configuration still contains `repo_server=http://9.3.2.182`
and the old `build_path=kopdevbuilds/`. Verify the HTTP address and change it for
your results server:

```text
repo_server=http://ci-http-results.pperf.tadn.ibm.com
```

For your existing `/home/jenkins/http_repo/crtl/repo/rhel/` and `.../sles/`
locations, the publisher derives HTTP `/crtl/repo/rhel/` and `/crtl/repo/sles/`.
Other filesystem layouts use the configured `build_path` as their HTTP prefix.
The new publisher generates modern Petitboot entries rather than using the old
PowerKVM template. This is a downloadable installation tree; unattended install
settings/registration remain the responsibility of PowerVM_Install/installvm.py.

## Validate on the server

```bash
cd /home/jenkins/workspace/buildnotifier
/usr/bin/python3.9 -u start_build_notification.py --platform sles --check-only
/usr/bin/python3.9 -u start_build_notification.py --platform rhel --check-only
```

Check-only fetches listings and compares tracking files. It does not download
ISOs, mount, publish, or notify Jenkins. It may create logs/empty tracking files.

Then download/publish selected distros:

```bash
/usr/bin/python3.9 -u start_build_notification.py --platform sles
/usr/bin/python3.9 -u start_build_notification.py --platform rhel
# Both configured platforms (also the default when no options are supplied):
/usr/bin/python3.9 -u start_build_notification.py --platform both
```

Root privileges are required for loop mounting. FTP_USER and FTP_PASS environment
variables can override the configured credentials. No email or Slack messages
are sent by this overlay; existing Jenkins poll notification files are updated
only after successful download, checksum verification and publishing.

SLES updates do not install an OS on an LPAR. Verify the HTTP kernel/initrd URLs
and install tree before triggering your separate PowerVM_Install job. Registration
requirements are not changed here.

## Validation and limits

Nine offline tests cover four RHEL versions; SLES 15 and 16 discovery; flat and
architecture directories; individual/collective checksums; MD5/SHA256/SHA512;
corruption and download failure; verified cache reuse; publishing failure gating;
install-folder flattening; modern Petitboot paths; and non-destructive retries.
Python syntax compilation also passes. Tests simulate FTP and mounting/publishing;
actual IBM FTP access, ISO mount/copy and Jenkins execution must be verified on
ci-http-results. This package does not claim end-to-end PowerVM install validation.

If a new SLES directory format produces multiple source directories for the same
build ID, the script reports an ambiguity instead of silently choosing one.
An installation build without a usable checksum is skipped for retry.
