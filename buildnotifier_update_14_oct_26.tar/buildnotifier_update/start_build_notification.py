#!/usr/bin/python3
import argparse
import os
from Build_Engine.build_notification import build_check_copy

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Download and publish RHEL/SLES installation builds')
    parser.add_argument('--platform', choices=['rhel', 'sles', 'both'], default='both')
    parser.add_argument('--check-only', action='store_true', help='List new builds without downloading, mounting or notifying Jenkins')
    args = parser.parse_args()
    base = os.path.dirname(os.path.abspath(__file__))
    raise SystemExit(build_check_copy(base, args.platform, args.check_only))
