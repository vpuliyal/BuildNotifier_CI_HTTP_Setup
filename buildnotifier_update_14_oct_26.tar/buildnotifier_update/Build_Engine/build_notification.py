import os
import logging
from Build_Engine.rhel_obj import rhel_obj
from Build_Engine.suse_obj import suse_obj


def build_check_copy(BASE_PATH, platform='both', check_only=False):
    result = 0
    for name, runner in [('rhel', rhel_obj), ('sles', suse_obj)]:
        if platform not in ('both', name):
            continue
        os.chdir(BASE_PATH)
        try:
            result = max(result, runner(BASE_PATH, check_only=check_only))
        except Exception:
            logging.exception('%s BuildNotifier failed', name)
            result = 1
        finally:
            os.chdir(BASE_PATH)
    return result
