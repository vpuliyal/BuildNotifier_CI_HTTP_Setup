#!/usr/bin/python3
# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright IBM; SLES 16 layout support ported from the LTC package.
from Build_Engine.Distro import *
from Build_Engine.redhat_build_engine import RHEL
import hashlib
from urllib.parse import quote

class SUSE(Distro):
    populate_builds_copied = RHEL.populate_builds_copied
    LOG = RHEL.LOG
    restore_for_copy_again = RHEL.restore_for_copy_again
    _read_listing = RHEL._read_listing
    _listing_names = staticmethod(RHEL._listing_names)

    @staticmethod
    def release_directory(release):
        clean = re.sub(r'^SLES?-', '', release, flags=re.I)
        match = re.fullmatch(r'(\d+)(?:\.(\d+)|-SP(\d+))', clean, re.I)
        if not match:
            raise ValueError('Use SLES releases such as 16.1 or 15-SP7')
        return match.group(1) + 'sp' + (match.group(2) or match.group(3))

    def populate_builds_announced(self, user, password, release, release_build_link):
        builds_announced.clear()
        builds_copied.clear()
        new_builds.clear()
        md5link_announced.clear()
        self._suse_sources = {}
        clean = re.sub(r'^SLES?-', '', release, flags=re.I)
        pattern = re.compile(r'^SLES?-' + re.escape(clean) + r'-(.+)$', re.I)
        try:
            names = self._read_listing(user, password, release_build_link)
        except RuntimeError as error:
            print(str(error))
            return FAIL
        pairs = {}
        for name in names:
            match = pattern.fullmatch(name)
            if not match or re.search(r'minimal|online|vmware|sdk|packages', name, re.I):
                continue
            suffix = match.group(1)
            # New Full/Installer and older Server installation directories.
            if not re.search(r'Full|Installer|Server|Snapshot|RC|Beta|GM|QU', suffix, re.I):
                continue
            build = re.sub(r'(^|[-])(Full|Installer|Server)(?=-|$)', r'\1', suffix, flags=re.I)
            build = re.sub(r'-+', '-', build).strip('-').lower()
            build = re.sub(r'^\d+-(?=(rc|beta|gmc|gm|qu)\d*\b)', '', build)
            # Match legacy copied-build IDs for SLES 15.
            if '-SP' in clean.upper():
                build = clean.split('-', 1)[1].lower() + '-' + build
            if build in pairs and pairs[build] != name:
                previous = pairs[build]
                previous_full = bool(re.search(r'(^|-)Full(-|$)', previous, re.I))
                current_full = bool(re.search(r'(^|-)Full(-|$)', name, re.I))
                if previous_full and not current_full:
                    continue
                if current_full and not previous_full:
                    pairs[build] = name
                    continue
                print('Ambiguous SLES build ID:', build,
                      'Directories:', previous, 'and', name)
                return FAIL
            pairs[build] = name
        for build, name in sorted(pairs.items()):
            builds_announced.append(build)
            md5link_announced.append(name)
            self._suse_sources[build] = name
        print('SLES: Builds announced', builds_announced)
        return SUCCESS

    @staticmethod
    def _parse_checksums(text):
        entries = {}
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            match = re.fullmatch(r'([a-fA-F0-9]{32}|[a-fA-F0-9]{64}|[a-fA-F0-9]{128})\s+(?:\d+\s+)?\*?(?:\./)?([^/\s]+\.iso)', line)
            if match:
                digest, name = match.groups()
            else:
                match = re.fullmatch(r'(?:MD5|SHA256|SHA512)\s*\(([^/]+\.iso)\)\s*=\s*([a-fA-F0-9]+)', line, re.I)
                if not match:
                    continue
                name, digest = match.groups()
            algorithm = {32: 'md5', 64: 'sha256', 128: 'sha512'}.get(len(digest))
            if algorithm:
                entries[name] = (algorithm, digest.lower())
        return entries

    def _download_text(self, user, password, url):
        result = subprocess.run(['/usr/bin/wget', '-q', '-O', '-', user,
                                 password, url, '--no-check-certificate'],
                                stdout=subprocess.PIPE, universal_newlines=True)
        if result.returncode:
            raise RuntimeError('Checksum fetch failed: ' + url)
        return result.stdout

    @staticmethod
    def _verify_file(path, algorithm, expected):
        if not os.path.isfile(path):
            return False
        digest = hashlib.new(algorithm)
        with open(path, 'rb') as file:
            for chunk in iter(lambda: file.read(8 * 1024 * 1024), b''):
                digest.update(chunk)
        return digest.hexdigest() == expected

    def copy_suse_build(self, user, password, release, build_name, final_dir_structure):
        source = self._suse_sources[build_name]
        base = parser.get('Location', 'base_link').rstrip('/') + '/' + source + '/'
        try:
            names = self._read_listing(user, password, base)
            if 'ppc64le' in names:
                base += 'ppc64le/'
                names = self._read_listing(user, password, base)
            if 'iso' in names:
                base += 'iso/'
                names = self._read_listing(user, password, base)
            companions = parser.getboolean('Location', 'download_companion_isos', fallback=False)
            available = [name for name in names if 'ppc64le' in name
                         and name.endswith('.iso') and '-Online-' not in name]
            installs = [name for name in available
                        if '.install.iso' in name or re.search(r'Media1\.iso$', name)]
            if len(installs) != 1:
                raise RuntimeError('Expected one installation ISO in ' + base
                                   + '; found ' + str(len(installs)))
            isos = installs[:]
            if companions:
                isos += [name for name in available if '-Source.iso' in name
                         or '-Debug.iso' in name or 'Media2.iso' in name]
            collective = {}
            for checksum_name in ('SHA512SUMS', 'SHA512SUM', 'SHA256SUMS', 'SHA256SUM', 'MD5SUMS', 'MD5SUM'):
                if checksum_name in names:
                    collective = self._parse_checksums(self._download_text(user, password, base + checksum_name))
                    if collective:
                        break
            selected = {}
            for iso in isos:
                checksum = None
                for extension in ('.sha512', '.SHA512SUM', '.sha256', '.SHA256SUM', '.md5', '.MD5SUM'):
                    if iso + extension in names:
                        checksum = self._parse_checksums(self._download_text(user, password, base + quote(iso + extension))).get(iso)
                        if checksum:
                            break
                checksum = checksum or collective.get(iso)
                if not checksum:
                    raise RuntimeError('No usable checksum for ' + iso)
                selected[iso] = checksum
            self._suse_entries = selected
            with open(os.path.join(final_dir_structure, 'MD5SUM'), 'w') as file:
                for iso, (_, digest) in selected.items():
                    file.write(digest + '  ' + iso + '\n')
            for iso, (algorithm, digest) in selected.items():
                subdir = 'src' if '-Source.iso' in iso or 'Media2.iso' in iso else 'debug' if '-Debug.iso' in iso else ''
                folder = os.path.join(final_dir_structure, subdir)
                os.makedirs(folder, exist_ok=True)
                destination = os.path.join(folder, iso)
                if self._verify_file(destination, algorithm, digest):
                    print('Existing ISO checksum matches:', iso)
                    continue
                temporary = destination + '.part'
                print('Downloading SLES ISO:', base + iso)
                rc = subprocess.call(['/usr/bin/wget', '-q', user, password,
                                      base + quote(iso), '--no-check-certificate', '-O', temporary])
                if rc:
                    raise RuntimeError('wget failed (exit {}) for {}'.format(rc, iso))
                if not self._verify_file(temporary, algorithm, digest):
                    raise RuntimeError('{} checksum mismatch for {}'.format(algorithm, iso))
                os.replace(temporary, destination)
            return SUCCESS
        except (RuntimeError, OSError) as error:
            self.LOG(str(error), release, build_name)
            print(str(error))
            return FAIL

    def initiate_suse_build_copy(self, user, password, release, config_path):
        release_dir = self.release_directory(release)
        failures = False
        for build in new_builds[:]:
            folder_build = re.sub(r'^sp\d+-', '', build)
            destination = os.path.join(parser.get('Location', 'dir_structure'), release_dir, folder_build)
            os.makedirs(destination, exist_ok=True)
            if self.copy_suse_build(user, password, release, build, destination) != SUCCESS:
                failures = True
                continue
            directories = [destination]
            for subdir in ('src', 'debug'):
                path = os.path.join(destination, subdir)
                selected_names = getattr(self, '_suse_entries', {})
                if os.path.isdir(path) and any(name in selected_names for name in os.listdir(path) if name.endswith('.iso')):
                    directories.append(path)
            rc = self.publish_build(release_dir, folder_build,
                                    parser.get('Location', 'dir_structure'), directories + [config_path])
            if rc != SUCCESS:
                failures = True
                continue
            install = os.path.join(destination, 'install')
            if os.path.isdir(install):
                rc = subprocess.call(['cp', '-a', install + '/.', destination + '/'])
                if rc:
                    failures = True
                    continue
            boot = os.path.join(destination, 'boot', 'ppc64le')
            for name in ('linux', 'initrd'):
                target = os.path.join(boot, name)
                loader = os.path.join(boot, 'loader', name)
                if not os.path.isfile(target) and os.path.isfile(loader):
                    shutil.copy2(loader, target)
            if not all(os.path.isfile(os.path.join(boot, name)) for name in ('linux', 'initrd')):
                self.LOG('Missing boot/ppc64le/linux or initrd; not announcing build', release, build)
                failures = True
                continue
            with open(os.path.join(destination, 'version'), 'w') as file:
                file.write(build)
            self.notify_jenkins('sles', release_dir, folder_build, destination)
            self.update_builds_copied(release, build)
        return FAIL if failures else SUCCESS
