#!/usr/bin/python3
# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright: 2018 IBM
# Original authors: Vaishnavi Bhat, Praveen K Pandey, Samir A Mulani
# Supports dated RHEL directories and rolling RHEL-<version> directories.

from Build_Engine.Distro import *
from Build_Engine.publishBuild import rhel_boot_files
import hashlib
from urllib.parse import urlsplit, unquote
from html.parser import HTMLParser


class RHEL(Distro):
    def __init__(self, configFile):
        self._workspace_root = os.path.dirname(os.path.dirname(
            os.path.abspath(configFile)))
        super().__init__(configFile)

    def LOG(self, message, release, build):
        # Logging must not depend on publishBuild changing the working directory.
        log_dir = parser.get('Location', 'build_log')
        if not os.path.isabs(log_dir):
            log_dir = os.path.join(self._workspace_root, log_dir)
        os.makedirs(log_dir, exist_ok=True)
        path = os.path.join(log_dir, release + '_' + build + '.log')
        with open(path, 'a') as file:
            file.write('{} For release {} and build {} - {}\n'.format(
                datetime.datetime.now().isoformat(), release, build, message))
        logging.info('%s: %s: %s', release, build, message)

    def restore_for_copy_again(self, release, build, final_dir_structure):
        # Preserve existing extracted trees and mounted ISO directories.
        # Downloads overwrite their own .part files on the next attempt.
        self.LOG('Copy incomplete; retaining existing files for retry',
                 release, build)
        return SUCCESS

    @staticmethod
    def _file_md5(path):
        digest = hashlib.md5()
        with open(path, 'rb') as file:
            for chunk in iter(lambda: file.read(8 * 1024 * 1024), b''):
                digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _version_arch(release):
        parts = release.strip().split('-', 1)
        if len(parts) == 2:
            endian, version = parts
        else:
            endian, version = 'BE', parts[0]
        return version, 'ppc64le' if endian.upper() == 'LE' else 'ppc64'

    @staticmethod
    def _listing_names(html):
        class Links(HTMLParser):
            def __init__(self):
                super().__init__()
                self.names = set()
            def handle_starttag(self, tag, attrs):
                if tag == 'a':
                    href = dict(attrs).get('href')
                    if href:
                        self.names.add(unquote(urlsplit(href).path.rstrip('/').rsplit('/', 1)[-1]))
        links = Links()
        links.feed(html)
        return sorted(links.names)

    def _read_listing(self, user, password, url):
        result = subprocess.run(
            ['/usr/bin/wget', '-q', '-O', '-', user, password, url,
             '--no-check-certificate'],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            universal_newlines=True)
        if result.returncode:
            raise RuntimeError('Unable to read directory: ' + url)
        return self._listing_names(result.stdout)

    def _iso_dir(self, release, source_dir):
        version, arch = self._version_arch(release)
        variant = 'Server' if version.startswith('7') else 'BaseOS'
        return (parser.get('Location', 'base_link').rstrip('/') + '/'
                + source_dir + '/' + variant + '/' + arch + '/iso/')

    def populate_builds_announced(self, user, password, release,
                                  release_build_link):
        builds_announced.clear()
        builds_copied.clear()
        new_builds.clear()
        self._sources = {}
        self._expected_isos = {}
        version, arch = self._version_arch(release)
        root = 'RHEL-' + version
        dated = re.compile(r'^' + re.escape(root) + r'-(.+)$')
        try:
            names = self._read_listing(user, password, release_build_link)
            for name in names:
                match = dated.fullmatch(name)
                if match:
                    build = match.group(1)
                    builds_announced.append(build)
                    self._sources[(release, build)] = name
            # Use the rolling directory only when no dated snapshots exist.
            if root in names and not builds_announced:
                iso_names = self._read_listing(
                    user, password, self._iso_dir(release, root))
                pattern = re.compile(
                    r'^' + re.escape(root) + r'(?:\.0)?-(\d{8})\.(\d+)-'
                    + re.escape(arch) + r'-dvd1\.iso$')
                matches = [(name, pattern.fullmatch(name))
                           for name in iso_names]
                matches = [(name, match) for name, match in matches if match]
                if len(matches) != 1:
                    raise RuntimeError(
                        'Expected exactly one DVD compose in ' + root
                        + '; found ' + str(len(matches)))
                iso_name, match = matches[0]
                day, revision = match.groups()
                build = 'NIGHTLY-{}-{}-{}.{}'.format(
                    day[:4], day[4:6], day[6:8], revision)
                builds_announced.append(build)
                self._sources[(release, build)] = root
                self._expected_isos[(release, build)] = iso_name
        except RuntimeError as error:
            builds_announced.clear()
            logging.error('%s', error)
            print(str(error))
            return FAIL
        builds_announced[:] = sorted(set(builds_announced))
        logging.info('Builds announced %s', builds_announced)
        print('RHEL: Builds announced', builds_announced)
        return SUCCESS

    def populate_builds_copied(self, release, release_build_copied):
        builds_copied.clear()
        if release_build_copied is not None:
            with open(release_build_copied, 'r') as file:
                builds_copied.extend(line.strip() for line in file
                                     if line.strip())
        builds_copied.sort()
        logging.info('Builds copied %s', builds_copied)
        return SUCCESS

    def _source_iso_dir(self, release, build_name):
        version, _ = self._version_arch(release)
        source = getattr(self, '_sources', {}).get(
            (release, build_name), 'RHEL-' + version + '-' + build_name)
        return self._iso_dir(release, source)

    def copy_rhel_build(self, user, password, release, release_new,
                        build_name, final_dir_structure):
        rc = self.copy_rhel_md5(user, password, release, release_new,
                                build_name, final_dir_structure)
        if rc != SUCCESS:
            self.LOG('DVD checksum not available; will retry later',
                     release_new, build_name.lower())
            return MD5_NA
        return self.copy_rhel_iso(user, password, release, release_new,
                                  build_name, final_dir_structure)

    def copy_rhel_md5(self, user, password, release, release_new,
                      build_name, final_dir_structure):
        iso_dir = self._source_iso_dir(release, build_name)
        print('copy_rhel_md5: intermediatelink =', iso_dir)
        version, arch = self._version_arch(release)
        expected = getattr(self, '_expected_isos', {}).get((release, build_name))
        pattern = re.compile(r'^RHEL-' + re.escape(version) + r'(?:\.0)?-.*-'
                             + re.escape(arch) + r'-dvd1\.iso\.MD5SUM$')
        try:
            names = self._read_listing(user, password, iso_dir)
        except RuntimeError as error:
            self.LOG(str(error), release_new, build_name.lower())
            return FAIL
        candidates = [name for name in names if pattern.fullmatch(name)]
        if expected:
            candidates = [name for name in candidates
                          if name == expected + '.MD5SUM']
        if len(candidates) != 1:
            self.LOG('Expected one DVD checksum; found ' + str(len(candidates)),
                     release_new, build_name.lower())
            return FAIL
        if not hasattr(self, '_expected_isos'):
            self._expected_isos = {}
        self._expected_isos[(release, build_name)] = candidates[0][:-7]
        url = iso_dir + candidates[0]
        print('copy_rhel_md5: md5_file =', url)
        destination = final_dir_structure + '/MD5SUM'
        temporary = destination + '.part'
        rc = subprocess.call(
            ['/usr/bin/wget', '-q', user, password, url,
             '--no-check-certificate', '-O', temporary])
        if rc != 0:
            self.LOG('Checksum download failed, wget exit ' + str(rc),
                     release_new, build_name.lower())
            return FAIL
        entries = self._checksum_entries(temporary)
        if self._expected_isos[(release, build_name)] not in entries:
            self.LOG('Downloaded checksum has no expected DVD ISO entry',
                     release_new, build_name.lower())
            return FAIL
        os.replace(temporary, destination)
        return SUCCESS

    @staticmethod
    def _checksum_entries(path):
        entries = {}
        with open(path, 'r') as file:
            for line in file:
                # GNU md5sum and BSD MD5 formats; ignore comment headers.
                match = re.fullmatch(
                    r'([0-9a-fA-F]{32})\s+\*?([^/\s]+\.iso)\s*', line.strip())
                if match:
                    entries[match.group(2)] = match.group(1).lower()
                    continue
                match = re.fullmatch(
                    r'MD5\s*\(([^/]+\.iso)\)\s*=\s*([0-9a-fA-F]{32})',
                    line.strip())
                if match:
                    entries[match.group(1)] = match.group(2).lower()
        return entries

    def copy_rhel_iso(self, user, password, release, release_new,
                      build_name, final_dir_structure):
        expected = getattr(self, '_expected_isos', {}).get((release, build_name))
        try:
            entries = self._checksum_entries(final_dir_structure + '/MD5SUM')
        except OSError as error:
            self.LOG(str(error), release_new, build_name.lower())
            return FAIL
        if not expected or expected not in entries:
            self.LOG('DVD ISO missing from checksum file',
                     release_new, build_name.lower())
            return FAIL
        url = self._source_iso_dir(release, build_name) + expected
        print('copy_rhel_iso: full_iso_file =', url)
        destination = final_dir_structure + '/' + expected
        if os.path.isfile(destination):
            if self._file_md5(destination) == entries[expected]:
                print('Existing ISO checksum matches; skipping download:', expected)
                return SUCCESS
        temporary = destination + '.part'
        rc = subprocess.call(
            ['/usr/bin/wget', '-q', user, password, url,
             '--no-check-certificate', '-O', temporary])
        if rc != 0:
            self.LOG('ISO download failed, wget exit ' + str(rc),
                     release_new, build_name.lower())
            return FAIL
        if self._file_md5(temporary) != entries[expected]:
            self.LOG('Downloaded ISO checksum mismatch; will retry',
                     release_new, build_name.lower())
            return FAIL
        os.replace(temporary, destination)
        return SUCCESS

    def check_md5sum(self, release, build, final_dir_structure):
        # Override the inherited checker, which accepted mismatches.
        try:
            entries = self._checksum_entries(final_dir_structure + '/MD5SUM')
            iso_names = [name for name in os.listdir(final_dir_structure)
                         if name.endswith('.iso')]
            if len(iso_names) != 1 or iso_names[0] not in entries:
                raise ValueError('Expected one ISO with a matching checksum entry')
            digest = hashlib.md5()
            with open(os.path.join(final_dir_structure, iso_names[0]), 'rb') as file:
                for chunk in iter(lambda: file.read(8 * 1024 * 1024), b''):
                    digest.update(chunk)
            if digest.hexdigest() != entries[iso_names[0]]:
                raise ValueError('MD5SUM mismatch')
        except (OSError, ValueError) as error:
            self.LOG(str(error), release, build)
            return FAIL
        self.LOG('MD5SUM matches', release, build)
        return SUCCESS

    def initiate_rhel_build_copy(self, user, password, release, release_new,
                                 config_path):
        self._workspace_root = os.path.abspath(config_path)
        os.chdir(self._workspace_root)
        for build in new_builds[:]:
            final_dir_structure = (
                parser.get('Location', 'dir_structure')
                + release_new + '/' + build.lower())
            self.LOG('Starting copying of ' + build.lower(),
                     release_new, build.lower())
            rc = self.create_dir_structure(
                release_new, build.lower(), final_dir_structure)
            if rc != SUCCESS:
                return FAIL
            rc = self.copy_rhel_build(
                user, password, release, release_new, build, final_dir_structure)
            if rc != SUCCESS:
                self.restore_for_copy_again(
                    release_new, build.lower(), final_dir_structure)
                return FAIL
            rc = self.check_md5sum(
                release_new, build.lower(), final_dir_structure)
            if rc != SUCCESS:
                self.restore_for_copy_again(
                    release_new, build.lower(), final_dir_structure)
                return FAIL
            # Existing publishing code expects to work from the ISO directory.
            os.chdir(final_dir_structure)
            try:
                rc = self.publish_build(release_new, build.lower(),
                                   parser.get('Location', 'dir_structure'), config_path)
                if rc != SUCCESS:
                    return FAIL
                if rhel_boot_files(final_dir_structure) is None:
                    self.LOG('RHEL installer boot files missing; not announcing build', release_new, build.lower())
                    return FAIL
                self.Version(build.lower())
                self.update_builds_copied(release_new, build)
                self.notify_jenkins('rhel', release_new,
                                    build.lower(), final_dir_structure)
                self.notify_build_copy(self.__class__.__name__, release_new,
                                       build.lower(), final_dir_structure, config_path)
            finally:
                os.chdir(self._workspace_root)
        return SUCCESS
