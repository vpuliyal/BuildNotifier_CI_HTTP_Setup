#! /usr/local/bin/python

#Publish the build passed to. 
#Inputs needed 
#1) Build location /var/www/html/kopbuild211
#2) Name of the build 0.12.0               
#Unwrap the iso and copy the files
#Create the petitboot without default label
#Modify /etc/dhcpd.confd

import os, re, subprocess, time, pdb
variables_publish={}
SUCCESS=0
FAIL=1
BUILD_LOCATION_DOESNT_EXIST = 2
ISO_NOT_FOUND = 3
MOUNT_FAILURE = 4
COPY_FILE_FAILURE = 5
ISO_DIR_CREATION_FAILURE=''

def rhel_boot_files(build_path):
    """Return a complete boot-file pair from the extracted installation tree."""
    for kernel, initrd in (
        ('ppc/ppc64/vmlinuz', 'ppc/ppc64/initrd.img'),
        ('images/pxeboot/vmlinuz', 'images/pxeboot/initrd.img'),
    ):
        if all(os.path.isfile(os.path.join(build_path, name))
               for name in (kernel, initrd)):
            return kernel, initrd
    return None

def create_Petitboot (release, build_name, location, new_petitboot_file, default_flag):
    """
      Read the petitboot_template and change Tags with real values
    """
    # Generate entries for modern installation trees rather than the old
    # PowerKVM template (ppc/ppc64/vmlinuz and LiveOS).
    repo_server = variables_publish['repo_server'].rstrip('/')
    if '/crtl/repo/' in location:
        http_path = 'crtl/repo/' + location.split('/crtl/repo/', 1)[1].strip('/')
    else:
        http_path = variables_publish['build_path'].strip('/')
    url = repo_server + '/' + http_path + '/' + release + '/' + build_name
    if re.fullmatch(r'\d+\.\d+(?:le|be)', release):
        boot_files = rhel_boot_files(os.path.join(location, release, build_name))
        if boot_files is None:
            return FAIL
        kernel, initrd = boot_files
        arguments = 'inst.repo=' + url + ' console=hvc0 console=tty0'
    elif re.fullmatch(r'\d+sp\d+', release):
        kernel, initrd = 'boot/ppc64le/linux', 'boot/ppc64le/initrd'
        arguments = 'install=' + url + ' console=hvc0 console=tty0'
    else:
        return FAIL
    with open(new_petitboot_file, 'w') as file:
        file.write('label Netboot_Install_{}_{}\n kernel {}/{}\n initrd {}/{}\n append {}\n'.format(
            release, build_name, url, kernel, url, initrd, arguments))
    return SUCCESS

def unWrap_iso(build_and_location):
    for index, build_path in enumerate(build_and_location, 1):
        images = sorted(name for name in os.listdir(build_path) if name.endswith('.iso'))
        if len(images) != 1:
            return ISO_NOT_FOUND
        mount_dir = os.path.join(build_path, 'iso' + str(index))
        os.makedirs(mount_dir, exist_ok=True)
        if os.path.ismount(mount_dir):
            return MOUNT_FAILURE
        rc = subprocess.call(['mount', '-o', 'loop,ro',
                              os.path.join(build_path, images[0]), mount_dir])
        if rc:
            return MOUNT_FAILURE
        try:
            rc = subprocess.call(['cp', '-a', mount_dir + '/.', build_path + '/'])
        finally:
            unmount_rc = subprocess.call(['umount', mount_dir])
        if rc or unmount_rc:
            return COPY_FILE_FAILURE
    return SUCCESS

def check_dir_iso (build_and_location):
   """
     Check for the location and build to be  present
   """
 
   #if ( os.path.isdir(build_and_location) is not True ):
   #   return BUILD_LOCATION_DOESNT_EXIST
   #else :
       #Check for iso file to be present
   command = "/bin/ls -l" + " " + build_and_location + "| grep iso | grep -qv \"^d\""
   rc = subprocess.call([command], shell=True)
   if ( rc != 0 ):
       return ISO_NOT_FOUND

def Log (log_file, string) :
   """
      Open the log_file in write mode and insert string
   """
   log_file = os.path.join(config_file_path, log_file)
   os.makedirs(os.path.dirname(log_file), exist_ok=True)
   with open(log_file, 'a') as file :
      localtime = time.asctime(time.localtime(time.time()))
      final_log = localtime+" "+string+'\n'
      file.write(final_log)
   return 0

def publish (release, build_name, location, build_log, config_file) :
   build_dir = []
   global config_file_path 
   if (type(config_file) == list) :
       config_file_path = config_file[-1]
       build_dir = config_file[:-1]
   else:
        config_file_path = config_file
        build_loc = location + '/' + release + '/' + build_name
        build_dir.append(build_loc)
   config_path = config_file_path + '/config/publish_config'
   with open(config_path, 'r') as file :
       for line in file:
           if not line.strip() or line.lstrip().startswith('#'):
               continue
           var, value = line.split('=', 1)
           variables_publish[var] = value.strip()

   rc = unWrap_iso (build_dir)
   if ( rc == MOUNT_FAILURE ):
      Log (build_log, 'Mount of iso failed. Failing publish')
      return FAIL
   elif (rc == COPY_FILE_FAILURE):
      Log (build_log, 'Couldnt copy contents of iso to %s' % location)
      return FAIL
   elif rc != SUCCESS:
       Log(build_log, 'ISO extraction failed: ' + str(rc))
       return FAIL
   else :
       Log (build_log, 'Successfully unwrapped iso')

   """
      Create the arguments for petitboot
   """
   new_petitboot_file = build_dir[0] + "/" + 'petitboot.conf'
   default_flag = 'No'
   rc = create_Petitboot (release, build_name, location, new_petitboot_file, default_flag)
   if ( rc == FAIL ):
       Log (build_log, 'Petitboot for build' + build_name + 'creation failed.')
       Log (build_log, 'Manual intervention required')
       return FAIL
   else :
       Log (build_log, 'Petitboot for build' + build_name + 'created successfully')
       return SUCCESS

   #modify_dhcp()
   #Read dhcp configs from dhcp_config file
 
   #restart_dhcpd ()

   #notify_team() 
