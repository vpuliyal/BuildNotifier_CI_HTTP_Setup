from Build_Engine.redhat_build_engine import *


def rhel_obj(platform_config_path, check_only=False):
    os.chdir(platform_config_path)
    engine = RHEL(os.path.join(platform_config_path, 'config', 'rhel_config.ini'))
    user = '--user=' + os.environ.get('FTP_USER', parser.get('Email', 'user'))
    password = '--password=' + os.environ.get('FTP_PASS', parser.get('Email', 'passwd'))
    configured_base = parser.get('Location', 'base_link')
    failed = False
    for release in engine.reading_configFile():
        version, arch = engine._version_arch(release)
        local_release = version + ('le' if arch == 'ppc64le' else 'be')
        # Permit mixed RHEL 9 and 10 releases in one config.
        base = re.sub(r'/RHEL-\d+/?$', '/RHEL-' + version.split('.')[0] + '/', configured_base)
        parser.set('Location', 'base_link', base)
        if engine.populate_builds_announced(user, password, release, base) != SUCCESS:
            failed = True
            continue
        engine.populate_builds_copied(release, engine.build_copied(local_release))
        pending = engine.compare_for_newbuild()
        if pending and not check_only:
            rc = engine.initiate_rhel_build_copy(user, password, release, local_release, platform_config_path)
            if rc == SUCCESS:
                engine.Latest(local_release)
            else:
                failed = True
    if not check_only:
        with open(os.path.join(platform_config_path, 'buildfile'), 'a') as file:
            for value in get_value():
                file.write(value + '\n')
    return FAIL if failed else SUCCESS
