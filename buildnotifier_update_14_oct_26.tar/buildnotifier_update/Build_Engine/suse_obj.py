from Build_Engine.suse_build_engine import *


def suse_obj(platform_config_path, check_only=False):
    os.chdir(platform_config_path)
    engine = SUSE(os.path.join(platform_config_path, 'config', 'suse_config.ini'))
    user = '--user=' + os.environ.get('FTP_USER', parser.get('Email', 'user'))
    password = '--password=' + os.environ.get('FTP_PASS', parser.get('Email', 'passwd'))
    base = parser.get('Location', 'base_link')
    failed = False
    for release in engine.reading_configFile():
        if engine.populate_builds_announced(user, password, release, base) != SUCCESS:
            failed = True
            continue
        engine.populate_builds_copied(release, engine.build_copied(release))
        if engine.compare_for_newbuild() and not check_only:
            if engine.initiate_suse_build_copy(user, password, release, platform_config_path) != SUCCESS:
                failed = True
    if not check_only:
        with open(os.path.join(platform_config_path, 'buildfile'), 'a') as file:
            for value in get_value():
                file.write(value + '\n')
    return FAIL if failed else SUCCESS
